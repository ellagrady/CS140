//
//  parser.c
//  
//
//  Created by Ella Grady on 2/23/22.
//

#include <stdio.h>
#include "parser.h"
#include <ctype.h>
#include <stdlib.h>

#include <string.h>

#define MAX_LENGTH 200

/* void mystrcpy(char *out, char *in) {
    
    int i = 0;
    // repeat until reach null character
    while(in[i] != '\0') {
        out[i]=in[i];
        i++;
    }
    out[i]= '\0'; // NULL terminate the output
}

void mystrcpypointer(char *out, char *in) {
    
    while (*in != '\0') {
        *out =*in;
        
        //advance the pointers
        in++;
        out++;
    }
    
    *out = '\0';
} */
int removespacesandtabs(char *out, char *in) {
    
    int inindex = 0;
    int outindex = 0;
    // repeat until reach null character

    while(in[inindex] != '\0' && in[inindex] != '/') {
        // if(in[inindex] == '/'){
            // break;
        // }
        if(!isspace(in[inindex])) {
            out[outindex]=in[inindex];
            outindex++;
        }
        inindex++;
    }
    out[outindex]= '\0'; // NULL terminate the output
    return (out[0] != '\0');
}



/* int removespacesandtabspointer(char *out, char *in) {
    
    
    // int inindex = 0;
    // int outindex = 0;
    // repeat until reach null character
    while(*in != '\0' && *in != '/') {
        // if(in[inindex] == '/'){
            // break;
        // }
        if(!isspace(*in)) {
            *out = *in;
            out++;
        }
        in++;
    }
    *out= '\0'; // NULL terminate the output
    
    return (out[0] != '\0');
}
 */
FILE * readfile(char *outfile, char *infile) {
    FILE *infilepointer;
    infilepointer = fopen(infile, "r");
    FILE *outfilepointer;
    outfilepointer = fopen(outfile, "w+");
    if (infilepointer == NULL)
    {
        perror("Error: could not open file ");
        exit(1);
    }
    
    char buffer[MAX_LENGTH];
    // char templine[MAX_LENGTH];
    char outputline[MAX_LENGTH];
    // fputs("hello", outfilepointer);
    fgets(buffer, MAX_LENGTH, infilepointer );
    while (!feof(infilepointer)){
        
        removespacesandtabs(outputline, buffer);
        
        if(strlen(outputline) != 0 && outputline[0] != '\n') {
            fputs(outputline, outfilepointer);
            //fputs('\0', outfilepointer);
            fputs("\n\0", outfilepointer);
        }
        fgets(buffer, MAX_LENGTH, infilepointer );
    }
    // fputs("next", outfilepointer);
    
    // close the file
    fclose(infilepointer);
    fclose(outfilepointer);
    return outfilepointer;
}

void sequenceoutput(char *outfile, char *infile) {
    FILE *infilepointer;
    infilepointer = fopen(infile, "r");
    FILE *outfilepointer;
    outfilepointer = fopen(outfile, "w");

    
    char buffer[MAX_LENGTH];
    fgets(buffer, MAX_LENGTH, infilepointer);
    // fputs("hello", outfilepointer);
    while (!feof(infilepointer)){
        // puts("hello");
        //fputs("hello", outfilepointer);
        if (buffer[0] == '@') {
            // puts("A-Command");
            fputs("A_COMMAND", outfilepointer);
            //fputs('\0', outfilepointer);
            fputs("\n\0", outfilepointer);
        }
        else if (buffer[0] == '(') {
            // puts("L-Command");
            fputs("L_COMMAND", outfilepointer);
            //fputs('\0', outfilepointer);
            fputs("\n\0", outfilepointer);
        }
        else {
            // puts("C-Command");
            fputs("C_COMMAND", outfilepointer);
            //fputs('\0', outfilepointer);
            fputs("\n\0", outfilepointer);
        }
        fgets(buffer, MAX_LENGTH, infilepointer);
    }
    // puts("check", outfilepointer);
    fclose(infilepointer);
    fclose(outfilepointer);
}




