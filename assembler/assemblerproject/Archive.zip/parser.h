//
//  parser.h
//  
//
//  Created by Ella Grady on 2/23/22.
//

#ifndef parser_h
#define parser_h

#include <stdio.h>

int removespacesandtabs(char *out, char *in);
int removelines(char *out, char *in);

FILE * readfile(char *outfile, char *infile);

void sequenceoutput(char *outfile, char *infile);


#endif /* parser_h */
